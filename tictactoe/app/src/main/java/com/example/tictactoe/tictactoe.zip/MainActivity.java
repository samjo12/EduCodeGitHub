package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CellView cell00 = findViewById(R.id.cell00);
        cell00.setCoordinates(0, 0);
        CellView cell01 = findViewById(R.id.cell01);
        cell00.setCoordinates(0, 1);
        CellView cell02 = findViewById(R.id.cell02);
        cell00.setCoordinates(0, 2);
        CellView cell10 = findViewById(R.id.cell10);
        cell00.setCoordinates(1, 0);
        CellView cell11 = findViewById(R.id.cell11);
        cell00.setCoordinates(1, 1);
        CellView cell12 = findViewById(R.id.cell12);
        cell00.setCoordinates(1, 2);
        CellView cell20 = findViewById(R.id.cell20);
        cell00.setCoordinates(2, 0);
        CellView cell21 = findViewById(R.id.cell21);
        cell00.setCoordinates(2, 1);
        CellView cell22 = findViewById(R.id.cell22);
        cell00.setCoordinates(2, 2);


    }
}