package com.example.tictactoe;

public enum CellState {
    NONE,
    X,
    O
}
