using System.Windows;

namespace CefSharp.Wpf.Example
{
    /// <summary>
    /// Interaction logic for SimpleMainWindow.xaml
    /// </summary>
    public partial class SimpleMainWindow : Window
    {
        public SimpleMainWindow()
        {
            InitializeComponent();
        }
    }
}
